package com.lti.view;

import com.lti.model.Flight;

public class FlightView {
	public void showFlightDetails(int flightNumber, String flightName) {
		System.out.println("--Flight Information--");
		System.out.println("Flight Number : "+flightNumber);
		System.out.println("Flight Name   :  "+flightName);
		System.out.println("----------------------");
	}
	public void showFlightDetails(Flight theFlight) {
		System.out.println("--Flight Information--");
		System.out.println("[Flight Number :  "+theFlight.getFlightNumber()+"]");
		System.out.println("[Flight Name   :  "+theFlight.getFlightName()+"]");
		System.out.println("----------------------");
	}
}

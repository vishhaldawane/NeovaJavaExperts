package com.design.pattern.creational.builder;

import java.util.ArrayList;
import java.util.List;
/*
 * Builder pattern builds a complex object using simple objects and 
 * using a step by step approach. This type of design pattern comes 
 * under creational pattern as this pattern provides one of the best 
 * ways to create an object.

	A Builder class builds the final object step by step. 
	This builder is independent of other objects.
 */

interface Item {
	   public String name();
	   public Packing packing();
	   public float price();	
}
interface Packing {
	   public String pack();
}

class Pizza implements Item {
	  public String name() { return "cheese pizza"; }
	   public Packing packing() {
		   Packing p = new Box();
		   return p;
	   }
	   public float price() { return 200.0f;}
}

class Box implements Packing {
	   public String pack() {
		   return "Box packing...";
	   }
}

class Wrapper implements Packing {

	   @Override
	   public String pack() {
	      return "Wrapper";
	   }
}

class Bottle implements Packing {

	   @Override
	   public String pack() {
	      return "Bottle";
	   }
}


abstract class Burger implements Item {

	  @Override
	   public Packing packing() {
	      return new Wrapper();
	   }

	   @Override
	   public abstract float price();
}

abstract class ColdDrink implements Item {

		@Override
		public Packing packing() {
	       return new Bottle();
		}
		@Override
		public abstract float price();
}

class VegBurger extends Burger {

	   @Override
	   public float price() {//mandate
	      return 25.0f;
	   }

	   @Override
	   public String name() { //mandate
	      return "Veg Burger";
	   }
}

class ChickenBurger extends Burger {

	   @Override
	   public float price() {
	      return 50.5f;
	   }

	   @Override
	   public String name() {
	      return "Chicken Burger";
	   }
}

class Coke extends ColdDrink {

	   @Override
	   public float price() {
	      return 30.0f;
	   }

	   @Override
	   public String name() {
	      return "Coke";
	   }
}

class Pepsi extends ColdDrink {

	   @Override
	   public float price() {
	      return 35.0f;
	   }

	   @Override
	   public String name() {
	      return "Pepsi";
	   }
}

	

class Meal {
	   private List<Item> items = new ArrayList<Item>();	

	   public void addItem(Item item){
	      items.add(item);
	   }

	   public float getCost(){
	      float cost = 0.0f;
	      
	      for (Item item : items) {
	         cost += item.price();
	      }		
	      return cost;
	   }

	   public void showItems(){
	   
	      for (Item item : items) {
	         System.out.print("Item : " + item.name());
	         System.out.print(", Packing : " + item.packing().pack());
	         System.out.println(", Price : " + item.price());
	      }		
	   }	
}

class MealBuilder {

	   public Meal prepareVegMeal (){
	      Meal meal = new Meal();
	      meal.addItem(new VegBurger());
	      meal.addItem(new Coke());
	      return meal;
	   }   

	   public Meal prepareNonVegMeal (){
	      Meal meal = new Meal();
	      meal.addItem(new ChickenBurger());
	      meal.addItem(new Pepsi());
	      return meal;
	   }
}

public class BuilderPatternTest {
	   public static void main(String[] args) {
	   
	      MealBuilder mealBuilder = new MealBuilder();

	      Meal vegMeal = mealBuilder.prepareVegMeal();
	      System.out.println("Veg Meal");
	      vegMeal.showItems();
	      System.out.println("Total Cost: " + vegMeal.getCost());

	      Meal nonVegMeal = mealBuilder.prepareNonVegMeal();
	      System.out.println("\n\nNon-Veg Meal");
	      nonVegMeal.showItems();
	      System.out.println("Total Cost: " + nonVegMeal.getCost());
	   }
}


abstract class MusicalInstrument
{
	abstract void play();
}
abstract class StringBasedMusicalInstrument extends MusicalInstrument
{
	void play() {
		System.out.println("string based.. play");
	}
}
class Guitar extends StringBasedMusicalInstrument
{
	
}

//Guitar g = new Guitar();   g.play();


interface Graphics
{
	void flip();
	default void turning() {
		//1.8 features
	}
}
interface GraphicalCard extends Graphics
{
	//void flip() { }
}





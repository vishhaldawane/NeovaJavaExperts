package jungle.use;
import jungle.tree.Monkey;
public class TestIt {
	public static void main(String[] args) {
		Monkey monkey = new Monkey();
		monkey.jump();
		monkey.eat();
		monkey.swing();// diff pacakge + non child
		monkey.hoop();
	}
}
class Gorilla extends Monkey {
	void foo() {
		Monkey m = new Monkey();
		m.jump();
		m.eat();// not - error
		m.swing(); //diff package + child - error
		m.hoop();	//error
		
		jump();
		eat(); //error
		swing();
		hoop(); //error
	}
}
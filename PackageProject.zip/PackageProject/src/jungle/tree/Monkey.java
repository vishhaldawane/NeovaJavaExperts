package jungle.tree;

public class Monkey {
	public Monkey() {
		System.out.println("Monkey ctor...");
	}
	public void jump() {
		eat();
		System.out.println("Jumping monkey...");
	}
	private void eat() {
		System.out.println("Monkey is eating...");
	}
	protected void swing() {
		eat();
		System.out.println("Monkey is eating...");
	}
	void hoop() {
		eat();
		System.out.println("Monkey is hooping...");
	}
}
class Chimpanzee extends Monkey {
	//protected void swing() { }
	void fun() {
		eat(); // not 
		swing();// same package + child
		hoop(); //  same package + child
		jump(); // same pacakge + child
	}
}
class TestIt {
	public static void main(String[] args) {
		Monkey monkey = new Monkey();
		monkey.eat();
		monkey.swing();// same package + non child
		monkey.hoop(); // same package + non child
	}
}

class Gorilla extends Monkey {
	void foo() {
		Monkey m = new Monkey();
		m.jump();
		m.eat();// not - error
		m.swing(); //diff package + child - error
		m.hoop();	//error
		
		jump();
		eat(); //error
		swing();
		hoop(); //error
	}
}